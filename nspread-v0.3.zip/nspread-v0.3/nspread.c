

////////////////////////////////////
////// NSPREAD 
////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h> //
// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  //define getcwd
// time 
#include <time.h>
#include <ncurses.h>

#define CELL_MAX 250

/// C based libraries (no ncurses)
#include "libc-strings.c"



int main( int argc, char *argv[])
{ 

    initscr(  );

    int rows, cols;  
    FILE *fp;
    int ch , i, j, k  ; 
    int posy , posx ; 
    getmaxyx( stdscr, rows, cols);
    char charo[PATH_MAX];
    char foochar[PATH_MAX];
    char cmdi[PATH_MAX];

    int  fileslot = 1;
    char filesource[ 20 ][PATH_MAX];
    strncpy(filesource[ fileslot ], "", PATH_MAX );


    int scrolly = 0;
    int scrollx = 0;
    int userselx = 1;
    int usersely = 2;
    int userselviewmaxx = 3;
    int userselviewmaxy = 3;

    //////////////////////////
    int colsize[55];
    for( i = 1 ; i <= 50 ; i++)
        colsize[ i ] = 8 ; 


    ////////////////////////////////
    char idata[55][55][CELL_MAX];
    for( i = 1 ; i <= 50 ; i++)
     for( j = 1 ; j <= 50 ; j++)
      strncpy(idata[j][i], "", CELL_MAX );



   void readit(){
         char readitline[PATH_MAX];
         int readline_y = 0;
         int readline_x = 1;
	 int readline_col = 1; 
         if ( fexist( filesource[ 1 ] ) == 1) 
         {
           fp = fopen( filesource[ 1 ] , "rb" ) ; 
           while (!feof(fp)) 
	   {
	       readline_col = 1; 
               fgets( readitline, PATH_MAX, fp); 
	       readline_y++;

               if(!feof(fp))
	       {
     for( readline_col = 1 ; readline_col <= userselviewmaxx ; readline_col++ ) 
     strncpy( idata[readline_y][ readline_col ], strsplit(readitline, ';', readline_col ) , CELL_MAX );
	       }
	   }
	   fclose( fp );
	 }
   }


   ///////////////
   int nspread_fileexist = 0;
   if ( argc == 2)
     if ( fexist( argv[1] ) == 1 )
     {
       strncpy(filesource[ fileslot ], argv[ 1 ], PATH_MAX );
       nspread_fileexist = 1;
       readit();
     }


  char *fdata( int yy, int xx )
  {
      char ptq[CELL_MAX];
      strncpy( ptq , strcut( strrlf( idata[ yy ][ xx ] ), 1  , colsize[ xx  ]   ) , CELL_MAX );


      if ( strcmp( ptq, "" ) == 0 )
      if ( yy == usersely ) 
      if ( xx == userselx ) 
         strncpy( ptq , "|-|", CELL_MAX );

      size_t siz = sizeof ptq ; 
      char *r = malloc( sizeof ptq );
      return r ? memcpy(r, ptq, siz ) : NULL;
  }




  int getcolposx( int doo )
  {
       int dooout = 0 ; 
       int dk; 
       for( dk = 1 ; dk <= doo ; dk++) 
         dooout = dooout + colsize[ dk-1 ]; 
       return dooout;
  }

   void checkparas(){
        if ( scrolly <= 0 ) scrolly = 0 ; 
        if ( scrollx <= 0 ) scrollx = 0 ; 
        if ( usersely <= 1 ) usersely = 1 ; 
        if ( userselx <= 1 ) userselx = 1 ; 
        if ( userselviewmaxx <= 1 ) userselviewmaxx = 1 ; 
        for( k = 1 ; k <= userselviewmaxx ; k++)  
 	 if ( colsize[ k ] <= 2 ) colsize[ k ] = 2 ; 
   }

   void drawit(){
    checkparas();
    attroff( A_REVERSE ); color_set( 0 , NULL );
    ncerase();
    attroff( A_REVERSE ); nchspace( 0, 0 , cols-1 );
    attroff( A_REVERSE ); 



    for( i = 0 ; i <= cols-1 ;  i++)
    {
      mvaddch( 1 , i, '-' );
      mvaddch( 3 , i, '-' );
      mvaddch( rows-2 , i, '-' );
    }


    for( j = 1 ; j <= rows-3 ;  j++)
    {
       mvaddch( j, 0,  '|' );
       mvaddch( j, cols-1,  '|' );
    }


    j = 2;
    int posxscroll = getcolposx( scrollx +1 ) + 1*scrollx ;

     attroff( A_REVERSE );
     posx = 1 ;  posy = 2 ; 
     for( i = 1 ; i <= 3 ; i++)  // y 
     {
        posx = getcolposx( i );
        mvprintw( 2 , i + posx-1  -posxscroll  , "|" );
	j = 1 ; 
        mvprintw( j , i + posx-1  -posxscroll , "+" );
	j = 3 ; 
        mvprintw( j , i + posx-1  -posxscroll , "+" );
        j = rows-2;
        mvprintw( j , i + posx-1  -posxscroll , "+" );
     }





     // HEADER CONTENT
     posy = 1; posx = 1 ; 
     for( i = 1 ; i <= userselviewmaxx ; i++)  // x 
     for( j = 1 ; j <= 1 ; j++)  // y 
     {
       posx = getcolposx( i );
       mvprintw( j + posy , i +posx -posxscroll ,  "%s" , fdata( j, i ) );
     }
     // CONTENT
     posy = 2   - scrolly  ; 
     posx = 1 ;
     for( i = 1 ;  i <= userselviewmaxx ; i++)  // x 
     for( j = 2 + scrolly  ; j + posy <= (rows-3) ; j++)  // y 
     {
        attroff( A_REVERSE );
        posx = getcolposx( i );
        mvprintw( j + posy , i + posx-1  -posxscroll , "|" );

        if ( usersely == j ) if ( userselx == i ) 
          attron( A_REVERSE );

        mvprintw( j + posy , i + posx -posxscroll  ,  "%s" , fdata( j, i ) );
      }



    attroff( A_REVERSE ); 
    nchspace( rows-1, 0 , cols-1 );

    mvprintw( 0, 0 ,      "[NSPREAD (GNU)]");
    mvprintw( rows-1, 0 , "#[Sheet-1]|%d,%d|{S%d,%d}<W%d>", 
    userselx, usersely,
    scrollx,  scrolly,
    colsize[ userselx ] );
    
    attroff( A_REVERSE ); 
   }



    int nspread_gameover = 0; 
    while( nspread_gameover == 0 ){
     readit();
     drawit();
     ch = getch();
     switch( ch )
     {
       case 'q':
         nspread_gameover = 1;
         break;

       case 'j':
         usersely++;
         break;
       case 'k':
         usersely--;
         break;
       case 'l':
         userselx++;
         break;
       case 'h':
         userselx--;
         break;

       case '{':
       case 'a':
         scrollx--;
         break;
       case '}':
       case 'f':
         scrollx++;
         break;
       case 'd':
         scrolly--;
         break;
       case 's':
         scrolly++;
         break;

       case '1':
       case '2':
       case '3':
       case '4':
       case '5':
       case '6':
       case '7':
       case '8':
       case '9':
         userselx = ch - 48; 
         break;

       case 'u':
         scrolly-=4;
         usersely-=4;
         break;
       case 'n':
         scrolly+=4;
         usersely+=4;
         break;

       case ']':
         userselviewmaxx++;
         break;
       case '[':
         userselviewmaxx--;
         break;

       case 'g':
         ch = getch();
	 if ( ch == 'g' ) 
	 {
          userselx = 1; 
          usersely = 2; 
          scrollx = 0; 
          scrolly = 0; 
	 }
	 else if ( ch == 'r' ) 
	 {
            colsize[ 1 ] = 9;
            colsize[ 2 ] = 19;
            colsize[ 3 ] = 30;
	 }
         break;

       case '>':
         colsize[ userselx ]++;
         break;
       case '<':
         colsize[ userselx ]--;
         break;

       case 'v':
                    strncpy( cmdi, " vim  " , PATH_MAX );
                    strncat( cmdi , " \"" , PATH_MAX - strlen(cmdi) - 1);
                    strncat( cmdi , filesource[ 1 ] , PATH_MAX - strlen(cmdi) - 1);
                    strncat( cmdi , "\"" , PATH_MAX - strlen(cmdi) - 1);
                    strncat( cmdi , " " , PATH_MAX - strlen(cmdi) - 1);
		    ncruncmd( cmdi );
         break;


     }
    }

    endwin();
    return 0;
}



